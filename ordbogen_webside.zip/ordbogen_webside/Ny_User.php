<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <form>
        <font size="5" color="green">Laven en bruger</font>
        <table>
            
          <tr>
                    <td width="78">Brugernavn</td>
                    <td width="6">:</td>
                    <td width="294"><input name="Ny User nave" type="text"></td>
                </tr>
                <tr>
                    <td>password</td>
                    <td>:</td>
                    <td><input name="Ny User password" type="text"></td>
                    <td><input type="submit" name="Oprat" value="Oprat" ></td>
            </tr>     
        </table>
      
    </form>
            
    <body>
        <?php
    
        ?>
    </body>
</html>
